'use strict'

// ?Constants
const btnCreate = document.querySelector('#btn__create');
const btnRandom = document.querySelector('#btn__random');
const btnReset = document.querySelector('#btn__reset');
const btnStart = document.querySelector('#btn__start');

const raceTrack = document.querySelector('#race__track');
const userMessage = document.querySelector('#user__message');
const radioButtons = document.querySelectorAll('input[type="radio"]');
const raceTrackRect = raceTrack.getBoundingClientRect();
const finish = raceTrackRect.width - 100;



// ?Default State
btnReset.disabled = true;
btnStart.disabled = true;

let arrCars = [];
let arrWinners = [];


// ?Car Images Database
const carImages = {
  Rover : {
    Tomato: 'rover-red.png',
    Blueberry: 'rover-blue.png',
    Banana: 'rover-yellow.png',
    Avocado: 'rover-green.png'
  },
  Beetle: {
    Tomato: 'beetle-red.png',
    Blueberry: 'beetle-blue.png',
    Banana: 'beetle-yellow.png',
    Avocado: 'beetle-green.png'
  },
  Tesla: {
    Tomato: 'tesla-red.png',
    Blueberry: 'tesla-blue.png',
    Banana: 'tesla-yellow.png',
    Avocado: 'tesla-green.png'
  },
  Mini: {
    Tomato: 'mini-red.png',
    Blueberry: 'mini-blue.png',
    Banana: 'mini-yellow.png',
    Avocado: 'mini-green.png'
  }
};


// ?Create Button
btnCreate.addEventListener('click', function() {

userMessage.textContent = 'Create one more car'

          // Getting values from user input
  let brandInput = document.querySelector('.main form input[name=brand]:checked'); 
  let colorInput = document.querySelector('.main form input[name=color]:checked');
  let speedInput = document.querySelector('.main form input[name=speed]:checked');

          // If user didn't choose one of the radiobuttons
  if(!brandInput || !colorInput || !speedInput) {
    userMessage.innerHTML = '<span class="alert">You have to choose at least one brand,<br>one color and one speed<br>before create a car</span>';
    return;
  };

          // Adding cars till the array with cars will contain 4 cars
  if(arrCars.length < 4)  {

      btnRandom.disabled = true;
      btnReset.disabled = false;

          // Getting image url from the database and adding it to the track
      const imageSrc = carImages[brandInput.value][colorInput.value];
      const carImage = document.createElement('img');
      carImage.src = "img/" + imageSrc;
      raceTrack.appendChild(carImage);
    
          // Creating car object and pushing it to the car array
    const car = {
        brand: brandInput.value,
        color: colorInput.value,
        speed: speedInput.value,
        image: carImage,
        positionX: 10,
      };
    arrCars.push(car);

          // Buttons state during car creation
    if(arrCars.length === 4) {
      btnStart.disabled = false;
      btnCreate.disabled = true;
      userMessage.textContent = 'Ready to Go!';
    } else {
      btnStart.disabled = true;
    };

    speedInput.disabled = true;
    speedInput.checked = false;
};
});
 

// ?Random Button
btnRandom.addEventListener('click', function() {
  
  btnCreate.disabled = true;
  btnRandom.disabled = true;
  btnReset.disabled = false;
  btnStart.disabled = false;

            // Getting brand names and colors from Image database
  const brands = Object.keys(carImages);
  const colors = Object.keys(carImages[brands[0]]);
  const speeds = [3, 4, 5, 6];

         // Creating a copy for each array
  let availableBrands = [...brands];
  let availableColors = [...colors];
  let availableSpeeds = [...speeds];


          // Creating cars randomly
  if(arrCars.length < 4) {
  for (let i = 0; i < 4; i++) {

      const brandIndex = Math.floor(Math.random() * availableBrands.length); // getting random number within the array length
      const brand = availableBrands.splice(brandIndex, 1)[0]; // remove brand with chosen index from the array and return this index

      const colorIndex = Math.floor(Math.random() * availableColors.length);
      const color = availableColors.splice(colorIndex, 1)[0];

      const speedIndex = Math.floor(Math.random() * availableSpeeds.length);
      const speed = availableSpeeds.splice(speedIndex, 1)[0];

          // Creating a car image from the calculation above and putting it to the track
      const imageSrc = carImages[brand][color];
      const carImage = document.createElement('img');
      carImage.src = "img/" + imageSrc;
      raceTrack.appendChild(carImage);

          // New car object is pushed to the car array
      const car = {
          brand: brand,
          color: color,
          speed: speed,
          image: carImage,
          positionX: 10,
      };
      arrCars.push(car);
  };
};

// Disable all radiobuttons
radioButtons.forEach(function(unableButtons) {
  unableButtons.disabled = true;  
});

userMessage.textContent = 'Ready to Go!';
});


// ?Reset Button
btnReset.addEventListener('click', function(){

  btnCreate.disabled = false;
  btnRandom.disabled = false;
  btnReset.disabled = true;
  btnStart.disabled = true;

          // Getting track image back to the starting position
  raceTrack.style.backgroundPositionX = '0px';
  
  userMessage.textContent = 'One more time?';
  
          // Chosing all images on the track and removing them one by one
  const createdCarsList = document.querySelectorAll('#race__track img'); 
    createdCarsList.forEach(function(carImage) { 
      carImage.remove(); 
    });
    
          // Emptying the car array
    arrCars = [];
   
          // Enable all radiobuttons one by one
    radioButtons.forEach(function(unableButtons) {
      unableButtons.disabled = false;
    })
});

    

// ?Start Button
btnStart.addEventListener('click', function() {

  btnCreate.disabled = true;
  btnRandom.disabled = true;
  btnReset.disabled = true;
  btnStart.disabled = true;  
  
  userMessage.textContent = 'Who is The Winner?';

          // Starting the race if car array has 4 cars
  if(arrCars.length === 4) {    
    
    function moveCar(car) {
      let posCar = car.positionX;
      let carSpeed = parseInt(car.speed); // getting car speed and a position from an object car

      function move() {
        posCar += carSpeed; // moving car with its speed
        car.positionX = posCar; // changing car position

          if (posCar >= finish) { // if car position is equal to the finish point, we got a winner
              car.positionX = finish; // car got on the finish
            
              // Creating a winner object and push it to the winner array
            const newWinner = {
                brand: car.brand,
                color: car.color,
                speed: car.speed,
                image: car.carImage,
                positionX: finish,
            };

            arrWinners.push(newWinner);
              stopBG(); // stop bg movement with a first car on finish
                
              } else { // If car not yet got to the finish, it continues to move
                car.image.style.left = posCar + 'px'; // changing image style to move the car picture

                if(posCar < finish) { // if the car is not on finish, use animation
                requestAnimationFrame(move);
                };
            };
                    // If array winners got 4 cars, the race is ended and the final message is shown
                    if(arrWinners.length === 4) {
                      // First place is for the first element of the winners array ect
                        userMessage.innerHTML = '🌟🌟🌟<span class="winner">Winner: </span>' + arrWinners[0].color + ' ' + arrWinners[0].brand + '🌟🌟🌟' + '<br>🌟🌟<span class="second__place">Second place: </span>' + arrWinners[1].color + ' ' + arrWinners[1].brand + '🌟🌟' + '<br>🌟<span class="third__place">Third place: </span>' + arrWinners[2].color + ' ' + arrWinners[2].brand + '🌟';
                        btnReset.disabled = false;
                    };
            };

          move();
          };

arrWinners = [];
arrCars.forEach(moveCar); // moving each car in car array
moveBG(); // moving background

};
});


// ?Background Movement Functions
let posBG = 0;
let bgAnimation;

function moveBG() {
  posBG -= 1.6; // background moves another direction than cars
  raceTrack.style.backgroundPositionX = posBG + 'px'; // moving bg pic
  bgAnimation = requestAnimationFrame(moveBG);
};

function stopBG() {
  cancelAnimationFrame(bgAnimation); // stop bg animation
  posBG = 0; // return bg image to the starting position
};


